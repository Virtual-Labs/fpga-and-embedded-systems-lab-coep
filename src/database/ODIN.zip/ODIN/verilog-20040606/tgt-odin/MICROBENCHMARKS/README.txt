This directory contains the microbenchmarks that I use as the first part of the regression test when checking if Odin is working.  These files have been 
collected from a variety of resources.  Many are derived from Brown and Vranesic's "Fundamentals of Digital Logic with Verilog Design".
The rest are built by me to test out specific instances that I thought were
important.  
