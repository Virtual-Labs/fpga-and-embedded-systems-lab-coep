#!/bin/bash

####################################################################################
#
# 13/08/2002 - This ctags this code
#
####################################################################################

ctags *.[ch] ../../t-dll*.cc ../../t-dll*.h ../../ivl_target.h ../PETER_LIB/include/*.h ../PETER_LIB/src/*.c ~/PROGRAMMING_TOOLS/libxml2-2.6.2/PETER_BIN/include/libxml2/libxml/
etags *.[ch] ../../t-dll*.cc ../../t-dll*.h ../../ivl_target.h ../PETER_LIB/include/*.h ../PETER_LIB/src/*.c
