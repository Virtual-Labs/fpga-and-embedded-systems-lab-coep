#!/bin/bash

../../ivl -C config_file.txt temp.v
