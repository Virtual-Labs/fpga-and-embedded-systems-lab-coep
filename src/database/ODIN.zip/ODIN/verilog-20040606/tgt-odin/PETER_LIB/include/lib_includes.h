#ifndef __LIB_INCLUDES_H
#define __LIB_INCLUDES_H
/********************************************************************
	Created 15/02/2002 paj
********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "peter_defs.h"
#include "lib_prototypes.h"

#include "linked-list.h"
#include "bitvector.h"
#include "string_functions.h"

#endif 
