
void od_add_to_mini_node_fifo (node_t *current_node, node_t *add_node, int pin);
void od_check_for_combinational_loops ();
