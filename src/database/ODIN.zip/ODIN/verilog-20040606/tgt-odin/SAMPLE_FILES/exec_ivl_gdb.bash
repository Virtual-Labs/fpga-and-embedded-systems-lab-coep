#!/bin/bash

gdb ../../ivl
