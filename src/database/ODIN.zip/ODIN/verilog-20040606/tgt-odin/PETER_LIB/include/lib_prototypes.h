#ifndef _LIB_PROTO
#define _LIB_PROTO
/*********************************************************************
Created - 02/14/2002 (paj)
*********************************************************************/

/* from basic_funcs.cc */
void *paj_alloc(int);

#endif 
